
from pyrogram import Client, filters
from pyrogram.types import ChatPermissions
import os
import json

API_ID = int(os.environ.get("API_ID"))
API_HASH = os.environ.get("API_HASH")
BOT_TOKEN = os.environ.get("BOT_TOKEN")
OWNER_ID = int(os.environ.get("OWNER_ID"))

admins_file = "admins.json"

app = Client("admin_guardian_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# بارگذاری لیست ادمین ها
def load_admins():
    try:
        with open(admins_file, "r") as f:
            return json.load(f)
    except:
        return []

# ذخیره لیست ادمین ها
def save_admins(admins):
    with open(admins_file, "w") as f:
        json.dump(admins, f)

# فقط ادمین اصلی بتونه ادمین اضافه کنه
@app.on_message(filters.command("addadmin") & filters.user(OWNER_ID))
def add_admin(client, message):
    if len(message.command) < 2:
        message.reply("لطفاً آیدی عددی فرد رو بفرست.")
        return
    admin_id = int(message.command[1])
    admins = load_admins()
    if admin_id not in admins:
        admins.append(admin_id)
        save_admins(admins)
        message.reply("ادمین جدید با موفقیت اضافه شد.")
    else:
        message.reply("این فرد قبلاً ادمین شده.")

# مانیتور حذف کاربر
@app.on_message(filters.left_chat_member)
def check_kick(client, message):
    remover = message.from_user
    admins = load_admins()
    if remover and remover.id in admins:
        for admin_id in admins:
            try:
                client.promote_chat_member(
                    message.chat.id,
                    admin_id,
                    can_manage_chat=False,
                    can_delete_messages=False,
                    can_promote_members=False,
                    can_change_info=False,
                    can_invite_users=False,
                    can_restrict_members=False
                )
            except Exception as e:
                print(f"خطا در دیس ادمین کردن: {e}")
        message.reply("ادمینی کاربر رو حذف کرد. همه دیس ادمین شدن.")
        save_admins([])

app.run()
